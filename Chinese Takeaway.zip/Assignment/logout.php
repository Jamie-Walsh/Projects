<?php
	session_start();
	session_destroy();
	
	$con=mysqli_connect("localhost","root","","jamie walsh-assignment");
	
	// Check connection
	if (mysqli_connect_errno())
	{
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	
	mysqli_query($con,"UPDATE menu SET Quantity = 0 WHERE Food_ID='1'");
		
	unset($_SESSION["account"]);
	header("Location:login.php");
	return;
?>