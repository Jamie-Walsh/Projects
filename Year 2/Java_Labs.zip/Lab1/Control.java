/****************************************
Control: the purpose of this class...
Author: Jamie Walsh
Date: 25/01/2018
*****************************************/

package Lab1; 

public class Control
{
	public static void main(String[] Args) 
	{
		Vehicle v1 = new Vehicle ("Bob");
		Vehicle v2 = new Vehicle ("Jamie Walsh" , "C16358056" , "Silver");
		
		System.out.println(v1);
		System.out.println(v2);
	}

}
