/****************************************
Control: the purpose of this class...
Author: Jamie Walsh
Date: 25/01/2018
*****************************************/

package Lab1;

public class Vehicle 
{
String ownerName;
String RegNumber;
String carColour;


public Vehicle(String ownerName)
{
	this.ownerName = ownerName;
}
public Vehicle(String ownerName, String registrationNumber, String carColour)
{
	this.ownerName = ownerName;
	this.RegNumber = registrationNumber;
	this.carColour = carColour;
	
}
public String toString()
{
	return "The owners name is " + ownerName + ",the registration number is " + RegNumber  + ", the car is "  + carColour + ".";
}

}
