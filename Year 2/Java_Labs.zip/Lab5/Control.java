package Lab5;

public class Control 
{

	public static void main(String[] args) 
	{
		BasicScreen MyScreen= new BasicScreen("Jamie's Screen");
		
	}

}
