/******************************************
*	Author: Jamie Walsh
*	Description: Program that will make a basic screen.
*	Date: 07/02/2018
******************************************/
package Lab5;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPanel;


public class BasicScreen extends JFrame implements ActionListener, MouseListener
{
	public JButton button1;
	public JButton button2;
	public JLabel label1;
	public JTextField field1;
	public JPanel panel1;
	
	BasicScreen(String title)
	{
		super(title);
		setSize(300,300);
		setLayout(new FlowLayout());
		
		button1= new JButton("Click me");
		add(button1);
		button1.addActionListener(this);
	    
	    button2= new JButton("Second Button");
	    add(button2);
	    button2.addActionListener(this);
	    
		label1= new JLabel("The panel is here.");
		
		field1= new JTextField("Name: ");
		add(field1);
		field1.addActionListener(this);
		field1.setPreferredSize( new Dimension( 200, 24 ) );
		field1.setToolTipText("Enter name here.");
		
		panel1= new JPanel();
	    panel1.addMouseListener(this);
	    panel1.setBackground(Color.RED);
	    panel1.setForeground(Color.BLACK);
	    add(panel1);
	    panel1.add(label1);
	    
	    setVisible(true);
	}
	
	public void actionPerformed(ActionEvent event)
	{
		if(event.getSource()== button1)
		{
			JOptionPane.showMessageDialog(this, "Button1 Clicked");
		}
		
		if(event.getSource()== button2)
		{
			JOptionPane.showMessageDialog(this, "Button2 Clicked");
		}
		
		String text = field1.getText();
		if(event.getSource()== field1)
		{
			JOptionPane.showMessageDialog(this, "You entered " + text);
		}
	}

	@Override
	public void mouseClicked(MouseEvent arg0) 
	{
		if(arg0.getButton() == MouseEvent.BUTTON1) 
		{
			JOptionPane.showMessageDialog(this, "Panel Was Clicked with the Left Button.");
        }
         if(arg0.getButton() == MouseEvent.BUTTON2) 
         {
  			JOptionPane.showMessageDialog(this, "Panel Was Clicked with the Middle Button.");
         }
         if(arg0.getButton() == MouseEvent.BUTTON3) 
         {
  			JOptionPane.showMessageDialog(this, "Panel Was Clicked with the Right Button.");
         }
	}

	@Override
	public void mouseEntered(MouseEvent arg0) 
	{
		if(arg0.getSource()== panel1)
		{
			JOptionPane.showMessageDialog(this, "�Mouse Entered the Panel.");
		}
	}

	@Override
	public void mouseExited(MouseEvent arg0) 
	{
		if(arg0.getSource()== panel1)
		{
			JOptionPane.showMessageDialog(this, "�Mouse Left the Panel.");
		}
	}

	@Override
	public void mousePressed(MouseEvent arg0) 
	{
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) 
	{
		
	}
}
