/****************************************
    Author: Jamie Walsh
    Date: 01/02/2018
*****************************************/

package Lab2;

public class Control 
{
	public static void main(String[] Args) 
	{
		Animal a1 = new Animal("Spot", "dog", 7, true, "brown");
		Animal a2 = new Animal("Leo", "pig", 24, false, "pink");
		
		//System.out.println(a1);
		System.out.println(a1);
		System.out.println(a2);
		
		System.out.println(a1.getName());
		System.out.println(a1.getBreed());
		System.out.println(a1.getAge());
		System.out.println(a1.getDomesticAnimal());
		System.out.println(a1.getColour());
		
		a1.makeNoise();
		a1.makeNoise(true);
	}
}
