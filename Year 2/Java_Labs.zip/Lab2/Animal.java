/****************************************
    Author: Jamie Walsh
    Date: 01/02/2018
*****************************************/

package Lab2; 

public class Animal 
{
	private String Name;
	private String Breed;
	private int Age;
	private boolean DomesticAnimal;
	private String Colour;
	
	//Constructors
	public Animal(String Name)
	{
		this.Name = Name;
	}
	
	public Animal(String Name, String Breed, int Age, boolean DomesticAnimal, String Colour)
	{
		this.Name = Name;
		this.Breed= Breed;
		this.Age= Age;
		this.DomesticAnimal= DomesticAnimal;
		this.Colour= Colour;
	}
	
	public String toString()
	{
		return "The Animals name is " + Name + ", it is a " + Breed  + " that is " + Age + " years old, " + Colour + " in colour and is " + DomesticAnimal + ".";
	}
	
	//Getters and Setters.
	public String getName()
	{
		return Name;
	}
	
	public void setName(String Name)
	{
		this.Name= Name;
	}
	
	public String getBreed()
	{
		return Breed;
	}
	
	public void setBreed(String Breed)
	{
		this.Breed= Breed;
	}
	public int getAge()
	{
		return Age;
	}
	
	public void setAge(int Age)
	{
		this.Age= Age;
	}
	
	public boolean getDomesticAnimal()
	{
		return DomesticAnimal;
	}
	
	public void setDomesticAnimal(boolean DomesticAnimal)
	{
		this.DomesticAnimal= DomesticAnimal;
	}
	
	public String getColour()
	{
		return Colour;
	}
	
	public void setColour(String Colour)
	{
		this.Colour= Colour;
	}
	
	
	//Noise Method
	public void makeNoise()
	{
		if(Breed== "dog")
		{
			System.out.println("Bark!");
		}
		else if(Breed== "pig")
		{
			System.out.println("Oink!");
		}
	}
	
	public void makeNoise(boolean old)
	{
		if(old==true)
		{
			System.out.println("Too Old.");
		}
		else
		{
			makeNoise();
		}
	}
}