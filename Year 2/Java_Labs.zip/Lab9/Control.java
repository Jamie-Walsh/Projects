package Lab9;

import java.util.ArrayList;

public class Control 
{
	public static void main(String[] args)
	{
		ArrayList<Person> PersonList= new ArrayList<Person>();
		
		PersonList.add(new Person("Jamie", "Walsh", "Dublin"));
		PersonList.add(new Person("Cat", "Garner", "Posh Land"));
		PersonList.add(new Person("Khurry", "Farooq", "Roscommon"));
		
		System.out.println(PersonList);
		
		GUI_9 myScreen= new GUI_9("Lab9");
	}
}
