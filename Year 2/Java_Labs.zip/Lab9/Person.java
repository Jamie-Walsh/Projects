package Lab9;

public class Person 
{
	private String firstName;
	private String surName;
	private String City;
	
	public Person(String firstName, String surName, String City)
	{
		this.firstName= firstName;
		this.surName= surName;
		this.City= City;
	}
	
	public String toString()
	{
		return ("\nThis person is called " + getFirstName() + " " + getSurName() + " and is from " + getCity());
	}
	
	
	public String getCity() 
	{
		return City;
	}
	public void setCity(String city) 
	{
		City = city;
	}
	
	public String getSurName() 
	{
		return surName;
	}
	public void setSurName(String surName) 
	{
		this.surName = surName;
	}

	public String getFirstName() 
	{
		return firstName;
	}

	public void setFirstName(String firstName) 
	{
		this.firstName = firstName;
	}
}
