package Lab9;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class GUI_9 extends JFrame implements ActionListener
{
	public JButton SaveButton;
	public JButton ShowButton;
	public JButton DeleteButton;
	
	public JTextField field1;
	public JTextField field2;
	public JTextField field3;
	public JTextArea area1;
	public int size;
	public int i;
	
	public ArrayList<Person> GUIarrayList= new ArrayList<>();
	
	GUI_9(String title)
	{
		super(title);
		setSize(600,500);
		setLayout(new FlowLayout());
		
		field1= new JTextField("First Name");
		add(field1);
		field1.addActionListener(this);
		field1.setPreferredSize( new Dimension( 100, 24 ) );
		field1.setToolTipText("Enter your First name.");
		
		field2= new JTextField("Second Name");
		add(field2);
		field2.addActionListener(this);
		field2.setPreferredSize( new Dimension( 100, 24 ) );
		field2.setToolTipText("Enter Your Second Name.");
		
		SaveButton= new JButton("Save");
		add(SaveButton);
		SaveButton.addActionListener(this);
		
		field3= new JTextField("City");
		add(field3);
		field3.addActionListener(this);
		field3.setPreferredSize( new Dimension( 350, 24 ) );
		field3.setToolTipText("Enter the city.");
		
		ShowButton= new JButton("Show All");
		add(ShowButton);
		ShowButton.addActionListener(this);

		DeleteButton= new JButton("Delete All");
		add(DeleteButton);
		DeleteButton.addActionListener(this);
		DeleteButton.setToolTipText("click to delete all items in the array list");
	    setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent event) 
	{
		String text1 = field1.getText();
		if (event.getSource()==field1)
		{
			JOptionPane.showMessageDialog(this, "You entered " + text1 + " inside the first name field");
		}
		
		String text2 = field2.getText();
		if (event.getSource()==field2)
		{
			JOptionPane.showMessageDialog(this, "You entered " + text2 + " inside the surname field");
		}
		
		String text3 = field3.getText();
		if (event.getSource()==field3)
		{
			JOptionPane.showMessageDialog(this, "You entered " + text3 + " inside the City field");
		}
		
		if(event.getSource()== SaveButton)
		{
			Person P1= new Person(text1, text2, text3);
			GUIarrayList.add(P1);
			JOptionPane.showMessageDialog(this, P1.toString());
		}
		
		if(event.getSource()== ShowButton)
		{
			area1 = new JTextArea("people added are:\n");
			area1.setEditable(false);
			area1.setLineWrap(false);
			add(area1);
			setVisible(true);
			
			for (Person element: GUIarrayList)
			{
				area1.append(element.toString());
			}
		}
			if (event.getSource()==DeleteButton)
			{
				area1.setText(" ");
				GUIarrayList.clear();
				JOptionPane.showMessageDialog(this, "Array list has been cleared.");
			}
	}
}

