package Lab4;

public class Control 
{
	public static void main(String[] args) 
	{
		//Objects
		Account a1= new Account("Jamie Walsh", 123, "912-000-987", "AIB", true, 300);
		DepositAccount d2= new DepositAccount("Jamie Walsh", 124, "913-000-987", "Ulster Bank", true, 700, 20);
		CurrentAccount c3= new CurrentAccount("Jamie Walsh", 125, "914-000-987", "PTSB", true, 500, -10);
		
		a1.Deposit(1000);
		a1.Withdraw(200);

		d2.Withdraw();
		
		c3.Withdraw(300);
		c3.checkCredit();
		c3.checkCredit("Account is in credit.");
		
		System.out.println(a1);
		System.out.println(d2);
		System.out.println(c3);
		
		a1.getDetails();
		a1.validatedAccount();
	}

}
