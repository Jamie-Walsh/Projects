package Lab4;

public class DepositAccount extends Account
{
	private double InterestRate;
	
	public DepositAccount(String AccountName, int AccountNumber, String SortCode, String BranchName, boolean InCredit, double AccBalance, double InterestRate)
	{
		super(AccountName, AccountNumber, SortCode, BranchName, InCredit, AccBalance);
		this.InterestRate=InterestRate;
	}
	//Methods
	public void Withdraw()
	{
		System.out.println("You cannot withdraw from a deposit account.\n");
	}

	public String toString()
	{
		return super.toString();
	}
	
	public double getInterestRate() 
	{
		return InterestRate;
	}

	private void setInterestRate(double interestRate) 
	{
		InterestRate = interestRate;
	}
}
