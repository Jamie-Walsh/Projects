package Lab4;

public interface ValidatedAccount 
{
	public void getDetails();
	public void validatedAccount();
}
