/******************************
 * Lab 4
 * Author: Jamie Walsh
 * 15-02-2018
 ******************************/

package Lab4;

public class Account implements ValidatedAccount
{
	private String AccountName;
	private int AccountNumber=0;
	private String SortCode;
	private String BranchName;
	private boolean InCredit;
	private double AccBalance;
	
	//Costructors
	public Account(String AccountName, int AccountNumber, String SortCode, String BranchName, boolean InCredit, double AccBalance)
	{
		this.setAccountName(AccountName);
		this.setAccountNumber(AccountNumber);
		this.setSortCode(SortCode);
		this.setBranchName(BranchName);
		this.setInCredit(InCredit);
		this.setAccBalance(AccBalance);
	}
	
	//Methods
	public double Deposit(double depAmount)
	{
		setAccBalance(getAccBalance() + depAmount);
		return getAccBalance();
	}
	
	public double Withdraw(double TakeAmount)
	{
		if(getAccBalance()<0)
		{
			setInCredit(false);
		}
		
		setAccBalance(getAccBalance()-TakeAmount);
		return getAccBalance();
	}
	
	public String toString()
	{
		return "Account name: " + AccountName + "\nAccount Number: " + AccountNumber + "\nSort Code: " + SortCode + "\nBranch Name: " + BranchName + "\nIn Credit: " + InCredit + "\nAccount Balance: " + AccBalance + "\n";
	}
	
	public void getDetails()
	{
		System.out.println("This is a normal account");
		System.out.println(AccountName);
		System.out.println(AccBalance);
	}
	
	public void validatedAccount()
	{
		System.out.println("Account Balance= �" + AccBalance);
	}
	
	//Getters and Setters.
	public String getAccountName() {
		return AccountName;
	}

	public void setAccountName(String accountName) {
		AccountName = accountName;
	}

	public int getAccountNumber() {
		return AccountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		AccountNumber = accountNumber;
	}

	public String getSortCode() {
		return SortCode;
	}

	public void setSortCode(String sortCode) {
		SortCode = sortCode;
	}

	public String getBranchName() {
		return BranchName;
	}

	public void setBranchName(String branchName) {
		BranchName = branchName;
	}

	public boolean isInCredit() {
		return InCredit;
	}

	public void setInCredit(boolean inCredit) {
		InCredit = inCredit;
	}

	public double getAccBalance() {
		return AccBalance;
	}

	public void setAccBalance(double accBalance) {
		AccBalance = accBalance;
	}
}