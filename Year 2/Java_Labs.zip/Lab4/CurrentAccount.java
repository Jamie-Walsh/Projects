package Lab4;

public class CurrentAccount extends Account
{
	private double PenaltyAmount;
	
	//Constructor
	public CurrentAccount(String AccountName, int AccountNumber, String SortCode, String BranchName, boolean InCredit, double AccBalance, double PenaltyAmount)
	{
		super(AccountName, AccountNumber, SortCode, BranchName, InCredit, AccBalance);
		this.PenaltyAmount= PenaltyAmount;
	}
	
	//Methods
	public double Withdraw(double TakeAmount)
	{
		if(TakeAmount>getAccBalance())
		{
			System.out.println("Insufficient funds.");
		}
		else
		{
			setAccBalance(getAccBalance()-TakeAmount);
			return getAccBalance();
		}
		return getAccBalance();
	}
	
	public String checkCredit()
	{
		String WarningMessage= "Account is in credit.";
		
		if(isInCredit()== false)
		{
			WarningMessage= "Account is not in credit.";
		}
		return WarningMessage;
	}
	
	public void checkCredit(String WarningMessage)
	{
		if(getAccBalance()<100 && getAccBalance()>0)
		{
			System.out.println(WarningMessage);
		}
	}
	
	public String toString()
	{
		return super.toString();
	}

	public double getPenaltyAmount() {
		return PenaltyAmount;
	}

	private void setPenaltyAmount(double penaltyAmount) {
		PenaltyAmount = penaltyAmount;
	}
}
