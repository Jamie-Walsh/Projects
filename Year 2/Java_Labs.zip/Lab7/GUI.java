/**********************
 * Author: Jamie Walsh
 * Lab week 7
 * 06/03/2018
 **********************/
package Lab7;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class GUI extends JFrame implements ActionListener
{
	public JButton FirstLetter;
	public JButton WordButton;
	public JButton FileButton;
	
	public JPanel panel1;
	public JLabel label1;
	
	public JTextField field1;
	public JTextField field2;
	public JTextField field3;
	
	GUI(String title)
	{
		super(title);
		setSize(600,500);
		setLayout(new FlowLayout());
		
		field1= new JTextField("Enter your text here.");
		add(field1);
		field1.addActionListener(this);
		field1.setPreferredSize( new Dimension( 200, 24 ) );
		field1.setToolTipText("Enter your text here.");
		
		field2= new JTextField("Enter the character to check for here.");
		add(field2);
		field2.addActionListener(this);
		field2.setPreferredSize( new Dimension( 100, 24 ) );
		field2.setToolTipText("Enter the character to check for here.");
		
		FirstLetter= new JButton("First letter?");
		add(FirstLetter);
		FirstLetter.addActionListener(this);
		
		field3= new JTextField("Enter a word to check for here.");
		add(field3);
		field3.addActionListener(this);
		field3.setPreferredSize( new Dimension( 350, 24 ) );
		field3.setToolTipText("Enter a word to check for here.");
		
		WordButton= new JButton("Word contained?");
		add(WordButton);
		WordButton.addActionListener(this);
		
		FileButton= new JButton("Search File");
		add(FileButton);
		FileButton.addActionListener(this);
		
		label1= new JLabel();
		add(label1);
	    
	    setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent event) 
	{
		String text1 = field1.getText();
		String text2 = field2.getText();
		String text3 = field3.getText();
		int Length = text2.length();
		
		if(text1.isEmpty() || !text1.contains(" "))
		{
			JOptionPane.showMessageDialog(this, "Error: Textfield 1 needs to contain a sentence.");
		}
		else
		{
			if(event.getSource()== FirstLetter)
			{
				if(Length>1 || text2.isEmpty())
				{
					JOptionPane.showMessageDialog(this, "Error: Please enter one single character to check if it is the first letter.");
				}
				else
				{
					if(text2.equalsIgnoreCase(text1.substring(0, 1)))
					{
						JOptionPane.showMessageDialog(this, "Yes! \"" + text2 + "\" is the first letter.");
					}
					else
					{
						JOptionPane.showMessageDialog(this, "Error: \"" + text2 + "\" is not the first letter.");
					}
				}
			}
			
			if(event.getSource()== WordButton)
			{
				if(text1.contains(text3))
				{
					JOptionPane.showMessageDialog(this, "Yes! \"" + text3 + "\" was found.");
				}
				else
				{
					JOptionPane.showMessageDialog(this, "Error: \"" + text3 + "\" was NOT found.");
				}
			}
			
			if(event.getSource()== FileButton)
			{
				FileReader myreader = new FileReader("textvalues.txt");
				myreader.openfile();
				String line= myreader.readfile();
				label1.setText(line);
			}
		}
	}
}