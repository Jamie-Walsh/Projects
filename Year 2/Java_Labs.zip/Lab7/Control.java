/**********************
 * Author: Jamie Walsh
 * Lab week 7
 * 06/03/2018
 **********************/
package Lab7;

public class Control 
{
	
	public static void main(String[] args)
	{
		GUI MyScreen= new GUI("Jamie's Screen");
	}
}
