/*********************
 * Author: Jamie Walsh
 * Lab Week 7
 * 06-03-2018
 *********************/

package Lab7;

import java.io.File;
import java.util.Scanner;

public class FileReader 
{
	String filename;
	File myfile;
	Scanner myScanner;
	
	FileReader(String fileName)
	{
		
	}
	
	public void openfile()
	{
		myfile = new File("textvalues.txt");
	}
	
	public String readfile()
	{
		String line= "Couldn't read the file.";
		
		try
		{
			myScanner = new Scanner(myfile);
			line= myScanner.nextLine();
		}
		catch(Exception ex)
		{
			System.out.println("Error: Exception " + ex.getMessage() + " caught.");
		}
		return line;
	}
}
