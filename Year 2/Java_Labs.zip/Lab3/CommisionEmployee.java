package Lab3;

public class CommisionEmployee extends Employee
{
	private double CommissionEarned;
	
	public CommisionEmployee(String FirstName, String SurName, int StaffNumber, double AnnualSalary, double CommissionEarned)
	{
		super(FirstName, SurName, StaffNumber, AnnualSalary);
		this.CommissionEarned=CommissionEarned;
	}
	
	public double CalculatePay(double AnnualSalary, double CommissionEarned)
	{
		return AnnualSalary/12 + CommissionEarned;
	}
	
	public String toString()
	{
		return super.toString() + "\nCommissionEarned: " + CommissionEarned;
	}
}
