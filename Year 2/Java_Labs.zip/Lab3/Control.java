package Lab3;

public class Control 
{
	public static void main(String[] args) 
	{
		Employee E1= new Employee("Jamie", "Walsh", 1234, 28000);
		
		HourlyEmployee H2= new HourlyEmployee("Eddie", "Murphy", 1000, 30000, 2080, 13);
		
		CommisionEmployee C3= new CommisionEmployee("Bill", "Jones", 2121, 10000, 17000);

		//System.out.println(E1);
		//System.out.println("Monthly Pay: �" + E1.CalculatePay(28000.00) + " per month.");
		
		//System.out.println(H2);
		//System.out.println("Full Year Pay: �" + H2.CalculatePay(2080, 13));
		
		//System.out.println(C3);
		//System.out.println("Monthly Pay: �" + C3.CalculatePay(10000, 1000)); 
		
		Employee[] myEmployee= new Employee[6];
		
		myEmployee[0]= new Employee("Jamie", "Walsh", 1234, 28000);
		myEmployee[1]= new Employee("Becca", "Simons", 8888, 29000);
		myEmployee[2]= new HourlyEmployee("Bob", "Walsh", 1000, 30000, 2080, 13);
		myEmployee[3]= new HourlyEmployee("Mary", "Walsh", 1001, 30000, 2080, 13);
		myEmployee[4]= new CommisionEmployee("Tom", "Jones", 2118, 11000, 15000);
		myEmployee[5]= new CommisionEmployee("John", "Jones", 2121, 10000, 17000);
		
		for(int i=0; i<(myEmployee.length); i++)
		{
			System.out.println(myEmployee[i]); 
		}
	}
}
