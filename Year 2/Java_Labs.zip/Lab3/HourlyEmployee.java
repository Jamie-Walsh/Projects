package Lab3;

public class HourlyEmployee extends Employee
{
	private double HoursWorked;
	private double HourlyRate;
	
	public HourlyEmployee(String FirstName, String SurName, int StaffNumber, double AnnualSalary, double HoursWorked, double HourlyRate)
	{
		super(FirstName, SurName, StaffNumber, AnnualSalary);
		this.setHoursWorked(HoursWorked);
		this.setHourlyRate(HourlyRate);
	}
	
	public double CalculatePay(double HoursWorked, double HourlyRate)
	{
		return HoursWorked*HourlyRate;
	}
	
	public String toString()
	{
		return super.toString() + "\nHoursWorked: " + HoursWorked + "\nHourlyRate: �" + HourlyRate;
	}

	public double getHoursWorked() {
		return HoursWorked;  
	}
 
	private void setHoursWorked(double hoursWorked) {
		HoursWorked = hoursWorked;
	}

	public double getHourlyRate() {
		return HourlyRate;
	}

	private void setHourlyRate(double hourlyRate) {
		HourlyRate = hourlyRate;
	}
}
