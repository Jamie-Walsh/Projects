/******************************************
*	Author: Jamie Walsh
*	Employee: Superclass that gives attributes to subclass.
*	Date: 07/02/2018
******************************************/
package Lab3;

//Creating the class.
public class Employee 
{
	//Setting Attributes.
	private String FirstName;
	private String SurName;
	private int StaffNumber;
	private double AnnualSalary;		

	//Constructors.
	public Employee(String FirstName, String SurName, int StaffNumber, double AnnualSalary)
	{
		this.setFirstName(FirstName);
		this.setSurName(SurName);
		this.setStaffNumber(StaffNumber);
		this.setAnnualSalary(AnnualSalary); 
	}
	
	public String toString()
	{
		return "\nEmployee Name: " + FirstName + " " + SurName + "\nStaff Number: " 
				+ StaffNumber + "\nAnnual Salary: " + AnnualSalary;
	}
	
	//Methods.
	public double CalculatePay(double AnnualSalary)
	{
		return AnnualSalary/12; 
	}

	//Getters and Setters
	public String getFirstName() {
		return FirstName;
	}

	private void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getSurName() {
		return SurName;
	}

	private void setSurName(String surName) {
		SurName = surName;
	}

	public int getStaffNumber() {
		return StaffNumber;
	}

	private void setStaffNumber(int staffNumber) {
		StaffNumber = staffNumber;
	}

	public double getAnnualSalary() {
		return AnnualSalary;
	}

	private void setAnnualSalary(double annualSalary) {
		AnnualSalary = annualSalary;
	}
}