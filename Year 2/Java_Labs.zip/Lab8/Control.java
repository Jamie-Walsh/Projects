package Lab8;

public class Control 
{
	
	public static void main(String[] args)
	{
		Date D1= new Date(2, 1, 2018);
		Job J1= new Job(40000, "Doctor", 123);
		Employee E1= new Employee("Jamie", "Walsh", new Date(28, 1, 1998), "Male", new Job(40000, "Doctor", 101), 123, new Date(13, 03, 2018));
		Person P1= new Person("Jamie", "Walsh", new Date(28, 1, 1998), "Male");
		
		System.out.println(D1);
		System.out.println(J1);
		System.out.println(E1);
		System.out.println(P1);
	}
}
