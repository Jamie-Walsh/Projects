package Lab8;

import java.io.File;
import java.util.Scanner;

public class FileProcessor 
{
	String filename;
	File myfile;
	Scanner myScanner;
	
	public FileProcessor(String fileName)
	{
		
	}
	
	public void openfile()
	{
		myfile = new File("roles.txt");
	}
	
	public String readfile()
	{
		String line= "Couldn't read the file.";
		
		try
		{
			myScanner = new Scanner(myfile);
			line= myScanner.nextLine();
		}
		catch(Exception ex)
		{
			System.out.println("Error: Exception " + ex.getMessage() + " caught.");
		}
		return line;
	}
}

