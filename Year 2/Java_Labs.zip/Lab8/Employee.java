package Lab8;

public class Employee extends Person
{
	private Job Job;
	private int PersonnelNumber;
	private Date StartDate;
	private static int NextNumber= 1000;
	
	public Employee(String FirstName, String SurName, Date DateOfBirth, String Gender, Job Job, int PersonnelNumber, Date StartDate)
	{
		super(FirstName, SurName, DateOfBirth, Gender);
		this.Job= Job;
		this.PersonnelNumber=NextNumber;
		NextNumber++;
		this.StartDate= StartDate;
	}

	public String toString()
	{
		return("Name: " + getFirstName() + " " + getSurName() + "\nDate of Birth: " + getDateOfBirth() + "\nGender: " + getGender() + "\n" + Job + "\nPersonnelNumber: " + PersonnelNumber + "\nStart Date: " + StartDate);
	}
	
	public static int getNextNumber() 
	{
		return NextNumber;
	}

	public static void setNextNumber(int NextNumber) 
	{
		Employee.NextNumber = NextNumber;
	}

	public Date getStartDate() 
	{
		return StartDate;
	}

	public void setStartDate(Date StartDate) 
	{
		this.StartDate = StartDate;
	}

	public int getPersonnelNumber() 
	{
		return PersonnelNumber;
	}

	public void setPersonnelNumber(int personnelNumber) 
	{
		this.PersonnelNumber = personnelNumber;
	}

	public Job getJob() 
	{
		return Job;
	}

	public void setJob(Job job) 
	{
		Job = job;
	}
}
