package Lab8;

public class Date 
{
	private int Day;
	private int Month;
	private int Year;
	
	public Date(int Day, int Month, int Year)
	{
		//To check if the day is valid.
		if(Day>=1 && Day<=31)
		{
			this.setDay(Day);
		}
		else
		{
			System.out.println("Error: Invalid Date Entered.");
		}
		
		//To check if the month is valid.
		if(Month>=1 && Month<=12)
		{
			this.setMonth(Month);
		}
		else
		{
			System.out.println("Error: Invalid Date Entered.");
		}
		
		this.setYear(Year);
	}
	
	public String toString()
	{
			return(Day + "-" + Month + "-" + Year);
	}
	
	public int getYear() 
	{
		return Year;
	}

	public void setYear(int year) 
	{
		Year = year;
	}

	public int getMonth() 
	{
		return Month;
	}

	public void setMonth(int month) 
	{
		Month = month;
	}

	public int getDay() 
	{
		return Day;
	}

	public void setDay(int day) 
	{
		Day = day;
	}
}
