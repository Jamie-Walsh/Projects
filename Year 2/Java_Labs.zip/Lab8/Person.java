package Lab8;

public class Person 
{
	private String FirstName;
	private String SurName;
	private Date DateOfBirth;
	private String Gender;
	
	public Person(String FirstName, String SurName, Date DateOfBirth, String Gender)
	{
		this.setFirstName(FirstName);
		this.setSurName(SurName);
		this.setDateOfBirth(DateOfBirth);
		this.setGender(Gender);
	}
	
	public String toString()
	{
		return("Name: " + getFirstName() + " " + getSurName() + "\nDate of Birth: " + getDateOfBirth() + "\nGender: " + getGender());
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public Date getDateOfBirth() {
		return DateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		DateOfBirth = dateOfBirth;
	}

	public String getSurName() {
		return SurName;
	}

	public void setSurName(String surName) {
		SurName = surName;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
}
