package Lab8;

import Lab8.FileProcessor;

public class Job 
{
	private double Salary;
	private String Role;
	private int JobID;
	
	public Job(double Salary, String Role, int JobID)
	{
		this.setSalary(Salary);
		this.setRole(Role);
		this.setJobID(JobID);
	}
	
	public void FileReader()
	{
		FileProcessor myreader = new FileProcessor("roles.txt");
		myreader.openfile();
		String line= myreader.readfile();
        
		if(Role.contains(line))
		{
			System.out.println("Role is contained in the file!");
		}
		else
		{
			System.out.println("Error: Role not in file.");
		}
	}
	
	public String toString() 
	{
		return("Salary: " + getSalary() + "\nRole: " + getRole() + "\nJob ID: " + getJobID());
	}
	
	public int getJobID() 
	{
		return JobID;
	}

	public void setJobID(int jobID) 
	{
		JobID = jobID;
	}

	public String getRole() 
	{
		return Role;
	}

	public void setRole(String role) 
	{
		Role = role;
	}

	public double getSalary() 
	{
		return Salary;
	}

	public void setSalary(double salary) 
	{
		Salary = salary;
	}
}
