/* CA Assignment-Semester 1.
Author: Jamie Walsh.
OS: Windows 10.
Compiler: Borland compiler.
Program that will operate on an
ATM machine which will allow
users to manage their PINs.
*/
#include <stdio.h>

int main()
{
    int Restart=0;
    int Option=0;
    int i;
    int Pin[4];
    int Assigned_Pin[4]={1, 2, 3, 4};
    int New_Pin1[4];
    int New_Pin2[4];
    int CorrectPin=0;
    int WrongPin=0;
    int YesOrNo=0;
    
    while(Restart==0) //The program will run until user confirms they want to end it.
    {
        //Displaying the Menu.
        printf("\n\nMENU\n");
        printf("1. Enter PIN and verify if it's correct.\n"); //Displaying Option 1.
        printf("2. Change PIN.\n");//Displaying Option 2.
        printf("3. Display the number of times the PIN was ");
        printf("entered (i) Correctly (ii) Incorrectly.\n"); //Displaying Option 3.
        printf("4. Exit Program.\n"); //Displaying Option 4.
        
        printf("Select an option.\n");
        scanf("%d", &Option);
        
        //use a switch statement for instructions for each option.
        switch(Option)
        {
            case 1: //If option 1 is chosen.
            {
                printf("\nEnter Your PIN number 1 digit at a time. ");
                printf("Press the Enter key between each digit.\n");
                
                for(i=0; i<4; i++) //Sets the variable 'i' to zero and increments it until it has reached 4. This is to enter values in to the array 'Pin' 1 at a time.
                {
                    scanf("%d", &Pin[i]); //This will read each number the user inputted and put them in the array, 'Pin', one by one.
                }
                
                if((Pin[0]!= Assigned_Pin[0]) || (Pin[1]!= Assigned_Pin[1]) || (Pin[2]!= Assigned_Pin[2]) || (Pin[3]!= Assigned_Pin[3])) //If any number in the pin is incorrect.
                {
                    WrongPin++; //This is for when option 3 is entered to count the amount of times the pin was entered incorrectly.
                    printf("Error: Incorrect PIN entered.\n");
                }
                else
                {
                    CorrectPin++; //This is for when option 3 is entered to count the amount of times the pin was entered correctly.
                    printf("PIN entered is Correct.\n");
                }
                break; //break is used to leave the current case you are in.
            } //End Case 1
            
            case 2: //If option 2 is chosen.
            {
                printf("\nEnter your new PIN number.\n");
                for(i=0; i<4; i++) //this is to enter values in to the array 'New_Pin1' 1 at a time.
                {
                    scanf("%d", &New_Pin1[i]); //This will read each number the user inputted and put them in the array, 'New_Pin1', one by one.
                }
                printf("\nRe-enter your new PIN number.\n");
                for(i=0; i<4; i++) //this is to enter values in to the array 'New_Pin2' 1 at a time.
                {
                    scanf("%d", &New_Pin2[i]); //This will read each number the user inputted and put them in the array, 'New_Pin2', one by one.
                }
                
                //use outer if else statement to check if the new PINs entered match.
                if((New_Pin1[0]!=New_Pin2[0]) || (New_Pin1[1]!=New_Pin2[1]) || (New_Pin1[2]!=New_Pin2[2]) || (New_Pin1[3]!=New_Pin2[3])) 
                {
                    printf("\nError: The two PINs entered do not match.\n");
                }
                else //If two PINs do match.
                {
                    //This is changing the assigned pin, (1234), to the new pin entered by the user.
                    Assigned_Pin[0]= New_Pin1[0];
                    Assigned_Pin[1]= New_Pin1[1];
                    Assigned_Pin[2]= New_Pin1[2];
                    Assigned_Pin[3]= New_Pin1[3];
                    printf("\nPIN number successfully changed.\n"); //confirmation for the user that the password was changed.
                }//End outer if else statement.
                break;
            } //End Case 2
                
            case 3://If option 3 is chosen.
            {
                printf("(i)PIN has been entered correctly %d time(s).\n", CorrectPin);
                printf("(ii)PIN has been entered incorrectly %d time(s).\n", WrongPin);
                break;
            } //End Case 3.
            
            case 4: //If option 4 is chosen.
            {
                printf("\nAre you sure you want to exit the program? 1=Yes. 2=No.\n");
                scanf("%d", &YesOrNo); //store the users answer in the variable, 'YesOrNo'.
                
                if(YesOrNo==1)
                {
                    Restart= Restart++; //increment 'Restart' so the while loop will end.
                    printf("\nProgram has ended. Goodbye.");
                }
                else
                {
                    printf("Program will continue.");
                }
                break;
            } //End Case 4.
            
            default: //If any number other that 1, 2, 3, or 4 is entered in for the option.
            {
                printf("Error: Invalid option entered.");
                Restart=Restart++;
                break;
            }//end default
        } //End switch
    } //End of while loop.
    
    flushall(); //Needed while using borland for the scanfs to work.
    getchar();
    return(0); //End Program.
}   //End main.
