#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

typedef struct Phonebook_Contacts
{
    char FirstName[20]; 
    char LastName[20];
    char email[30];
    char PhoneNumber[20]; 
} phone; 


void AddContact(phone * ); 
void DeleteEntry(phone * ); 
void PrintEntry(phone * ); 
void SearchForNumber(phone * );


int counter = 0;
char FileName[300]; 
FILE *pRead; 
FILE *pWrite; 


int main (void)
{      
    
    phone *phonebook; 
    phonebook = (phone*) malloc(sizeof(phone)*300); 
    int choice = 0; 
    
    if (phonebook == NULL)
    {
        printf("Out of Memory.");
        return 1;
    }
    else
    {
        do
        {
            //clrscr();
            printf("Phonebook \n\n"); 
            printf("1. Add contact\n");
            printf("2. Delete contact\n");
            printf("3. Display contacts\n");
            printf("4. Search for contact\n");
            printf("5. Exit Phonebook\n");
            
            scanf("%d", &choice);  
            
            switch (choice)
            {           
                case 1:    
                {
                    AddContact(phonebook); 
                    break;
                }
                
                case 2:   
                {
                    DeleteEntry(phonebook);
                    break;
                }
                
                case 3:   
                {
                    PrintEntry(phonebook);
                    break;
                }
                
                case 4:   
                {
                    SearchForNumber(phonebook); 
                    break;      
                }
                
                case 5: 
                {
                    clrscr();
                    printf("exiting");
                    return 0;
                }
                
                default: 
                {
                    clrscr();
                    printf("Invalid selection \n\n");
                    break;
                }
            }
        } while (choice <= 5); 
    }
} 


void AddContact (phone * phonebook)   //add contact function
{  
    pWrite = fopen("phonebook_contacts.dat", "a");
    
    if ( pWrite == NULL )
    {
        perror("error occurred");
        exit(EXIT_FAILURE); 
    }
    else
    {
        counter++;  
        realloc(phonebook, sizeof(phone)); 
        clrscr();
        printf("First Name: ");
        scanf("%s", phonebook[counter-1].FirstName);
        printf("Last Name: ");
        scanf("%s", phonebook[counter-1].LastName);
        printf("Phone Number : "); 
        scanf("%s", phonebook[counter-1].PhoneNumber);
        printf("email : "); 
        scanf("%s", phonebook[counter-1].email);
        
        fprintf(pWrite, "%s\t%s\t%s\n", phonebook[counter-1].FirstName, phonebook[counter-1].LastName, phonebook[counter-1].PhoneNumber, phonebook[counter-1].email);
        fclose(pWrite); 
    } 
} 

void DeleteEntry (phone * phonebook)
{
    int i;
    int j;
    char deleteFirstName[20];   
    char deleteLastName[20];  
    
    clrscr();
    printf("First name: ");
    scanf("%s", deleteFirstName);
    printf("Last name: ");
    scanf("%s", deleteLastName);
    
    for (j = 0; j < counter; j++)
    {
        if (strcmp(deleteFirstName, phonebook[j].FirstName) == 0) 
        {
            if (strcmp(deleteLastName, phonebook[j].LastName) == 0) 
            {
                for ( i = j; i < counter - 1; i++ )
                {
                    strcpy(phonebook[i].FirstName, phonebook[i+1].FirstName); 
                    strcpy(phonebook[i].LastName, phonebook[i+1].LastName); 
                    strcpy(phonebook[i].PhoneNumber, phonebook[i+1].PhoneNumber);
                    strcpy(phonebook[i].email , phonebook[i+1].email);           
                } 
                clrscr();
                printf("Contact removed\n\n");
                --counter; 
                return;
            } 
        } 
    }    
    clrscr();
    printf("contact not found.\n\n");
}

void PrintEntry (phone * phonebook)
{
    int i;
    
    clrscr();
    printf("Phonebook Entries:\n\n ");
    pRead = fopen("phonebook_contacts.dat", "r");
    if ( pRead == NULL)
    {
        perror("The following error occurred: ");
    }
    else
    {
        for( i = 0; i < counter; i++) 
        {
            clrscr();
            printf("\n(%d)\n", i+1); 
            printf("Full Name: %s %s\n", phonebook[i].FirstName, phonebook[i].LastName); 
            printf("Number: %s\n", phonebook[i].PhoneNumber); 
            printf("Email: %s\n", phonebook[i].email);
        } 
    } 
    fclose(pRead);
} 

void SearchForNumber (phone * phonebook)
{
    int i;
    char TempFirstName[20]; 
    char TempLastName[20]; 
    
    clrscr();
    printf("Please type the name of contact.");
    printf("\nFirst Name: ");
    scanf("%s", TempFirstName);
    printf("\nLast Name: ");
    scanf("%s", TempLastName);
    for (i = 0; i < counter; i++)
    {
        if (strcmp(TempFirstName, phonebook[i].FirstName) == 0) 
        {
            if (strcmp(TempLastName, phonebook[i].LastName) == 0) 
            {
                clrscr();
                printf("%s %s's contact info: %s\n %s\n", phonebook[i].FirstName, phonebook[i].LastName, phonebook[i].PhoneNumber, phonebook[i].email);
            } 
        } 
    }     
}