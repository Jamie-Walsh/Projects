package com.Assignment.C16358056;

public class Results 
{
	//Attributes.
	private int Percentage;
	private String file1;
	private String file2;
	
	//Constructor that takes in 3 variables from the GUI class.
	public Results(int percent, String f1, String f2)
	{
		//Instantiate the variables.
		this.setPercentage(percent);
		this.setFile1(f1);
		this.setFile2(f2);
	}
	
	//toString method that will return the message displaying the chance as a percentage that the two files are similar.
	public String toString()
	{
		return ("There is a " + getPercentage() + "% chance that \"" + getFile1() + "\" and \"" + getFile2() + "\" are about the same topic.\n");
	}

	//Getters and Setters.
	public int getPercentage() 
	{
		return Percentage;
	}

	public void setPercentage(int percentage) 
	{
		Percentage = percentage;
	}

	public String getFile1() 
	{
		return file1;
	}

	public void setFile1(String file1) 
	{
		this.file1 = file1;
	}

	public String getFile2() 
	{
		return file2;
	}

	public void setFile2(String file2) 
	{
		this.file2 = file2;
	}
}
