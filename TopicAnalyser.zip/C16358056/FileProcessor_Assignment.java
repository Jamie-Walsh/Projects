/********************************
 * Author: Jamie Walsh (C16358056)
 * File processor class
 * 05-03-2018
 ********************************/
package com.Assignment.C16358056;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.TreeMap;
import java.util.Scanner;
import java.util.Comparator;

public class FileProcessor_Assignment 
{
	//Attributes:
	Stop_Words myStop = new Stop_Words(); //Creating a local variable so you can use methods from the Stop_Words class.

 	//An array list containing the punctuation I will need to remove if contained in any word.
 	ArrayList<String> Punctuation= new ArrayList<String>
 	(Arrays.asList(",", ".", "\"", ":", ";", "+", "&", "?", "!", "*", "'", "(", ")", "/", "=", "[", "]", "_", "-"));

	private File myfile;
	private Scanner myScanner;
	private String filename;
	private String arrString;
	private String word;
	private String line;
	private Integer Frequency;
	private int i;
	
 	private TreeMap<String, Integer> takenMap= new TreeMap<String, Integer>();
 	private TreeMap<String, Integer> Map = new TreeMap<String, Integer>();
 	private TreeMap<String, Integer> finalMap = new TreeMap<String, Integer>();
 	private TreeMap<String, Integer> fixedMap = new TreeMap<String, Integer>(); 
 	private Comparator<String> Compare_Map = new Compare_Values(getTakenMap());

	//empty constructor.
	public FileProcessor_Assignment()
	{
		
	}
	
	//method to open the file
	public void openFile(String FileName) 
	{
		try
		{
			setMyfile(new File(FileName)); //sets myfile to the first file chosen by the user
		}
		catch(Exception ex) //Catches errors with reading/opening the file.
		{
			System.out.println("\nError: Could not open the file."); //prints the error message.
		}
	}
	
	public void openFile2(String FileName) 
	{
		try
		{
			setMyfile(new File(FileName)); //sets myfile to the first file chosen by the user
		}
		catch(Exception ex) //Catches errors with reading/opening the file.
		{
			System.out.println("\nError: Could not open the file."); //prints the error message.
		}
	}
	
	//method to read the file and put the contents in a HashMap.
	public TreeMap<String, Integer> readFile()
	{
		getMap().clear(); //Erase contents of the map so it can be used again and again in one run.
		
		try
		{			
			setMyScanner(new Scanner(getMyfile())); //set myScanner to the chosen file so you can can read it.
			
			while(getMyScanner().hasNextLine()) //While the file has another line.
			{
				setWord(getMyScanner().next());//set "word" to the next word in the file
				
				/* This for loop is so I can remove any 
				 * punctuation from the word so that it
				 * won't effect the counting later on. */
				for(setI(0); getI()<Punctuation.size();i++)
				{
					if( getWord().contains(Punctuation.get(getI())))
					{
						//This replaces the punctuation with empty space. Essentially removing it from the word.
						setWord(getWord().replace(Punctuation.get(getI()), "")); 
					}
				}
				
				//Use ".toLowerCase()" so capital lettered words aren't read as a different word.
				setFrequency(getMap().get(getWord().toLowerCase())); //Try set frequency to "word" if map contains the word.
				if(getFrequency() != null) //If frequency is empty after setting it to "Map.get(word.toLowerCase())" then the word is not yet in the map.
				{
					setFrequency(getFrequency() + 1); //Increment frequency if word is already in the map.
				}
				else
				{
					setFrequency(1); //Set frequency to 1 if the word hasn't been added to the map yet.
				}
				
				getMap().put(getWord().toLowerCase(), getFrequency()); //Add the word and frequency to the map.
			}//Repeat while the file has another line
			
			getMyScanner().close(); //close the file.
			
		}
		catch(Exception ex) //Catches errors with reading/opening the file.
		{
			System.out.println("Error: Exception \"" + ex.getMessage() + "\" caught."); //prints the error message.
		}
		 
		setMap(myStop.RemoveStopWords(getMap())); //send the map to the stopWords class to remove stop words from the map.

		//Create a tree map and call the ArrangeMap method to set it in order of the top words.
		setFinalMap(ArrangeMap(getMap())); 

		return getFinalMap(); //Send finalMap back to the GUI class.
	}

	//Method that arranges the map in order of the most common words (using key values).
	public TreeMap<String, Integer> ArrangeMap(TreeMap<String, Integer> tempMap)
	{
		//Create a local variable enabling you to use methods from the Compare_Values class.
		setCompare_Map(new Compare_Values(tempMap));
		//Create another tree map and send it to the Compare_Values class to be sorted.
		setFixedMap(new TreeMap<String, Integer>(getCompare_Map())); 
		
		getFixedMap().putAll(tempMap); //Copy the contents of tempMap and put them in to fixedMap.
		
		return getFixedMap();
	}

	//Getters and Setters
	public File getMyfile() {
		return myfile;
	}

	public void setMyfile(File myfile) {
		this.myfile = myfile;
	}

	public Scanner getMyScanner() {
		return myScanner;
	}

	public void setMyScanner(Scanner myScanner) {
		this.myScanner = myScanner;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getArrString() {
		return arrString;
	}

	public void setArrString(String arrString) {
		this.arrString = arrString;
	}

	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}

	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}

	public Integer getFrequency() {
		return Frequency;
	}

	public void setFrequency(Integer frequency) {
		Frequency = frequency;
	}

	public int getI() {
		return i;
	}

	public int setI(int i) {
		this.i = i;
		return i;
	}

	public TreeMap<String, Integer> getTakenMap() {
		return takenMap;
	}

	public void setTakenMap(TreeMap<String, Integer> takenMap) {
		this.takenMap = takenMap;
	}

	public TreeMap<String, Integer> getMap() {
		return Map;
	}

	public void setMap(TreeMap<String, Integer> map) {
		Map = map;
	}

	public TreeMap<String, Integer> getFinalMap() {
		return finalMap;
	}

	public void setFinalMap(TreeMap<String, Integer> finalMap) {
		this.finalMap = finalMap;
	}

	public TreeMap<String, Integer> getFixedMap() {
		return fixedMap;
	}

	public void setFixedMap(TreeMap<String, Integer> fixedMap) {
		this.fixedMap = fixedMap;
	}

	public Comparator<String> getCompare_Map() {
		return Compare_Map;
	}

	public void setCompare_Map(Comparator<String> compare_Map) {
		Compare_Map = compare_Map;
	}
}