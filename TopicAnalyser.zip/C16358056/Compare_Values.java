/*
 * Author: Jamie Walsh
 * 
 * Note: This is a class used to implement the comparator 
 * interface so I can have my map in order of its values.
 * 
 * Date: 14/04/2018
 */

package com.Assignment.C16358056;

import java.util.Comparator;
import java.util.HashMap;
import java.util.TreeMap;

public class Compare_Values implements Comparator<String> //This allows me to use the interface's methods.
{
	//Attributes
	private HashMap<String, Integer> newHMap = new HashMap<String, Integer>();

	//Constructor that takes in a HashMap
	public Compare_Values(TreeMap<String, Integer> oldMap)
	{
		//Copy the contents of the map received in to the newHMap.
		getNewHMap().putAll(oldMap);
	}

	/* REF:
	 * Comparator is an interface and one of the methods in it is
	 * "compare(T o1, T o2)". This compares its two arguments for
	 * order. It returns a negative integer, zero, or a positive 
	 * integer as the first argument is less than, equal to, 
	 * or greater than the second.
	 * I found out about this and how to use the proper syntax
	 * from: "https://docs.oracle.com/javase/7/docs/api/java/util/Comparator.html"
	 * End of REF */
	public int compare(String firstValue, String secondValue) 
	{
		//If firstValue is Greater than or equal to the second value return -1 (
		if(getNewHMap().get(firstValue) >= getNewHMap().get(secondValue))
		{
			return -1; //Return negative integer to show that it is true.
		}
		else
		{
			return 1; //Return positive integer to show that it is false.
		}	
	}

	//Getters and Setters
	public HashMap<String, Integer> getNewHMap() {
		return newHMap;
	}

	public void setNewHMap(HashMap<String, Integer> newHMap) {
		this.newHMap = newHMap;
	}
}