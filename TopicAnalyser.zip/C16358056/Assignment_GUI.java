/********************************
 * Author: Jamie Walsh (C16358056)
 * GUI Class
 * 28-03-2018
 ********************************/

package com.Assignment.C16358056;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.TreeMap;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

public class Assignment_GUI extends JFrame implements ActionListener
{
	//Attributes:
	private JTextField Field1;
	private JTextField Field2;
	private JTextField AddField;
	private JTextField DeleteField;
	
	private JPanel Panel1;
	private JPanel Panel2;
	private JPanel StopPanel;
	private JPanel Panel4;
	
	private JButton CompareButton;
	private JButton ShowButton;
	private JButton AddButton;
	private JButton DeleteButton;
	private JButton ResultsButton;
	private JButton DeleteResults;
	private JButton ChooseButton1;
	private JButton ChooseButton2;
	
	private String FirstChoice;
	private String SecondChoice;
	private String sWords;
	private String wordToDelete;
	private String Addition; 

	private JLabel Label1;
	private JLabel Label2;
	private JLabel StopLabel;
	private JLabel FileLabel;
	private JTextArea area1;
	private JTextArea listOfStops = new JTextArea(); 

	private JScrollPane Scroller = new JScrollPane();

	private TreeMap<String, Integer> Map1= new TreeMap<String, Integer>();
	private TreeMap<String, Integer> Map2= new TreeMap<String, Integer>();
	
 	private ArrayList<String> TopFifteenWords= new ArrayList<String>();
	private ArrayList<String> Top15_1= new ArrayList<String>();
	private ArrayList<String> Top15_2= new ArrayList<String>();
	private ArrayList<Results> ResultList= new ArrayList<Results>();
	private ArrayList<String> FullList = new ArrayList<String>(); //Creates an arraylist and puts all the values from the map in to the list.

	private Stop_Words myStop = new Stop_Words(); //Creating a local variable so you can use methods from the Stop_Words class.
	private fileChooser myChooser= new fileChooser(); //Enables this class to use methods from the fileChooser class.
	private FileProcessor_Assignment myReader = new FileProcessor_Assignment(); //Create a local variable so you can use the methods in the fileprocessor class.

	private int Percentage;
	private int i;
	private int Percent;
	private int Error2=0;
	private int Error1=0;

	//Constructor:
	Assignment_GUI(String title)
	{
		//Setting the size of the java Application.
		super(title);
		setSize(600,450);
		setLayout(null); //Set the layout to null so I can position each component manually using ".setBounds".
		
		//Creating the first Panel
		setPanel1(new JPanel());
		getPanel1().setBorder(new LineBorder(Color.BLUE, 3)); //Border around panel for cosmetic effect.
		getPanel1().setBackground(Color.WHITE); //Setting the colour of the panel.
		getPanel1().setBounds(0, 0, 585, 70); //Use ".setBounds(X, Y, Width, Height)" to position the panel where you want it in the application.
		add(getPanel1()); //Adds the panel to the screen.
		
		//Label to put in to 'Panel1"
		setLabel1(new JLabel("Jamie's Topic Analyser ")); //This is the title of the topic analyser
		getLabel1().setBackground(Color.WHITE);
		getLabel1().setFont(new Font("Serif", Font.BOLD, 35)); //Editing font.
		getLabel1().setForeground(Color.BLACK); //Setting the font colour.
		getPanel1().add(getLabel1()); //Putting the label in to the panel.
		
		//Creating the first Text field
		setField1(new JTextField());
		getField1().setText("Choose a \".txt\" file using the Browse button.");
		getField1().setToolTipText("Displays file directory once chosen."); //Will pop-up when user hovers over the text field.
		getField1().setBounds(170, 115, 300, 20); //Positioning the text field.
		add(getField1()); //Adds the text field to the screen.
				
		//Button that will use a JFileChooser.
		setChooseButton1(new JButton("Browse"));
		getChooseButton1().addActionListener(this); //Enables the button to perform actions.
		getChooseButton1().setBounds(475, 115, 80, 20);
		getChooseButton1().setToolTipText("Choose a File");
		add(getChooseButton1());
		
		//Button that will compare the two files.
		setCompareButton(new JButton("Compare"));
		getCompareButton().addActionListener(this); //Enables the button to perform actions.
		getCompareButton().setBounds(170, 175, 150, 30);
		getCompareButton().setToolTipText("Compare the Two Files");
		add(getCompareButton());
		
		//Creating the second Text field
		setField2(new JTextField()); 
		getField2().setText("Choose a \".txt\" file using the Browse button.");
		getField2().setToolTipText("Displays file directory once chosen.");
		getField2().setBounds(170, 140, 300, 20); //Positioning the text field.
		add(getField2());
		
		//Second button that will use a JFileChooser.
		setChooseButton2(new JButton("Browse"));
		getChooseButton2().addActionListener(this); //Enables the button to perform actions.
		getChooseButton2().setBounds(475, 140, 80, 20);
		getChooseButton2().setToolTipText("Choose a File to Compare.");
		add(getChooseButton2());
		
		//Creating the second panel.
		setPanel2(new JPanel());
		getPanel2().setBorder(new LineBorder(Color.BLUE, 3)); //Set border.
		getPanel2().setBackground(Color.WHITE);
		getPanel2().setBounds(0, 68, 150, 343); //Positioning the panel.
		add(getPanel2()); //Add the panel to the Screen.
		
		setLabel2(new JLabel("Extras")); //Title for the second panel.
		getLabel2().setBackground(Color.WHITE);
		getLabel2().setFont(new Font("Comic Sans", Font.BOLD | Font.ITALIC, 20)); //Editing font. Use "|" to make the font bold AND italic.
		getLabel2().setForeground(Color.BLACK); //Setting the font colour.
		getPanel2().add(getLabel2()); //Putting the label in to the panel.
		
		setShowButton(new JButton("See Stop Words"));
		getShowButton().addActionListener(this); //Enables the button to perform actions.
		getShowButton().setPreferredSize(new Dimension(130, 30));
		getShowButton().setToolTipText("Displays All the \"Stop Words\".");
		getPanel2().add(getShowButton()); //Putting the button in to Panel2
		
		setResultsButton(new JButton("Previous Results"));
		getResultsButton().addActionListener(this); //Enables the button to perform actions.
		getResultsButton().setPreferredSize(new Dimension(130, 30));
		getPanel2().add(getResultsButton()); //Putting the button in to Panel2.
		
		setDeleteResults(new JButton("Delete Results"));
		getDeleteResults().addActionListener(this); //Enables the button to perform actions.
		getDeleteResults().setPreferredSize(new Dimension(130, 30));
		getPanel2().add(getDeleteResults()); //Putting the button in to Panel2.
		
		setAddField(new JTextField());
		getAddField().setText("Enter word you wish to Add.");
		getAddField().setToolTipText("Type the word you would like to add to the \"stop words\" list.");
		getAddField().setBounds(170, 295, 300, 20); //Positioning the text field.
		add(getAddField());
		
		setAddButton(new JButton("Add")); //Allows user
		getAddButton().addActionListener(this); //Enables the button to perform actions.
		getAddButton().setBounds(475, 295, 80, 20);
		getAddButton().setToolTipText("Add word to \"Stop Words\".");
		add(getAddButton()); //Adds this button on to the screen.
		
		setDeleteField(new JTextField());
		getDeleteField().setText("Enter word you wish to delete.");
		getDeleteField().setToolTipText("Type the word you would like to delete from the \"stop words\" list.");
		getDeleteField().setBounds(170, 320, 300, 20); //Positioning the text field.
		add(getDeleteField());
		
		setDeleteButton(new JButton("Delete"));
		getDeleteButton().addActionListener(this); //Enables the button to perform actions.
		getDeleteButton().setBounds(475, 320, 80, 20);
		getDeleteButton().setToolTipText("Delete word from \"Stop Words\".");
		add(getDeleteButton()); //Adds this button on to the screen.
		
		//Creating panels to structure the screen.
		setStopPanel(new JPanel());
		getStopPanel().setBorder(new LineBorder(Color.BLUE, 3)); //Setting the border for layout purposes.
		getStopPanel().setBounds(145, 250, 440, 161); //(X-axis, Y-axis, Width, Height)
		add(getStopPanel());
		
		setStopLabel(new JLabel("Stop Words")); //Title for the third panel.
		getStopLabel().setFont(new Font("Comic Sans", Font.BOLD | Font.ITALIC, 20)); //Editing font.
		getStopLabel().setForeground(Color.BLACK); //Setting the font colour.
		getStopPanel().add(getStopLabel()); //Putting the label in to "StopPanel".
		
		setPanel4(new JPanel());
		getPanel4().setBorder(new LineBorder(Color.BLUE, 3));
		getPanel4().setBounds(145, 65, 440, 190); //Setting the location of the panel on the screen.
		add(getPanel4());
		
		setFileLabel(new JLabel("File Comparer ")); //Title for the fourth panel.
		getFileLabel().setFont(new Font("Comic Sans", Font.BOLD | Font.ITALIC, 20)); //Editing font.
		getFileLabel().setForeground(Color.BLACK); //Setting the font colour.
		getPanel4().add(getFileLabel()); //Putting the label in to the panel.
		
		setVisible(true); //Makes everything actually visible. Without it the application wouldn't show anything.
	}
	
	
	//Used to give the buttons functions
	public void actionPerformed(ActionEvent event) 
	{
		//This will execute when the ChooseButton1 is pressed.
		if(event.getSource()== getChooseButton1())
		{			
			//Calling these functions
			getMyChooser().fChoose();
		
			//Error checking.
			if(fileChooser.getError()== null)
			{
				//Setting the local variable "FirstChoice", to the "fileName" variable in the fileChooser class.
				setFirstChoice(fileChooser.getFileName());
				
				//Inputs the chosen file's directory in to the first text field.
				getField1().setText(getFirstChoice());
				
			}
			else //The user has cancelled choosing a file.
			{
				//Print message to confirm cancellation.
				JOptionPane.showMessageDialog(this, "File choosing operation has been cancelled.");
			}
		}
		
		//This will execute when the ChooseButton2 is pressed.
		if(event.getSource()== getChooseButton2())
		{
			//Local variable that allows you to use the methods in the fileChooser class.
			
			//Commencing these methods in the foreign class.
			getMyChooser().fChoose();
			
			if(fileChooser.getError()== null)
			{
				setSecondChoice(fileChooser.getFileName());
				
				//Inputs the chosen file's directory in to the second text field.
				getField2().setText(getSecondChoice());
				
			}
			else
			{
				//This prevents error messages and informs the user that they've cancelled selecting a file.
				JOptionPane.showMessageDialog(this, "File choosing operation has been cancelled.");
			}
		}
		
		//The compare button is the main function of this program.
		if(event.getSource()== CompareButton)
		{
			
			if(getField1().getText().contains(" ") ||  getField2().getText().contains(" ") || !getField1().getText().contains(".txt") || !getField2().getText().contains(".txt")) 
			{
				//If map 1 or 2 is empty, inform the user to select 2 files.
				JOptionPane.showMessageDialog(this, "Error: Ensure the chosen files are text files with no white space in the path.");
			}
			else
			{
				getMyReader().openFile(FirstChoice); //Send "first choice" in to the openfile1 method.
				setMap1(getMyReader().readFile()); //call the readFile method using "myReader".
				
				getMyReader().openFile2(SecondChoice); //Send "second choice" in to the openfile2 method.
				setMap2(getMyReader().readFile());
				
		        setTop15_1(FindTop15(getMap1())); //Send map1 in to "findtop15" and save the result as a variable.
		        setTop15_2(FindTop15(getMap2())); //Send map1 in to "findtop15" and save the result as a variable.
		        
		        System.out.println(getTop15_1());
		        System.out.println(getTop15_2());

		        setPercent(FindSimilarity(getTop15_1(), getTop15_2())); //Gives the likely hood as a percentage.
		        
		        JOptionPane.showMessageDialog(this, "There is a " + getPercent() + "% chance that \""
		        + FirstChoice + "\" and \"" + SecondChoice + "\" are about the same topic."); //Prints out the result to the user.
		        		      
		      //Create an object of the results class and pass the 3 necessary variables.
		        Results R1= new Results(getPercent(), FirstChoice, SecondChoice); 
		        getResultList().add(R1); //Add the object "R1" to the ResultsList.
			}
		}
		
		if(event.getSource()== getShowButton()) //if ShowButton is clicked
		{
			sWords= getMyStop().getStopW(); //Set sWords to the String of stop words.

			setListOfStops(new JTextArea(sWords)); //Create a text area and fill it with the stop words.
			setScroller(new JScrollPane(getListOfStops())); //Create a ScrollPane and put the text area in it.
			
			getListOfStops().setEditable(false); //So the user can only read the stop words.
			getListOfStops().setLineWrap(true); //makes the words go on the next line when it reaches the end of the text area.
			getListOfStops().setWrapStyleWord(true); //This prevents printing half of the word.
			getScroller().setPreferredSize(new Dimension( 450, 400 ) ); //Setting the size of the ScrollPanel.

			//This prints the ScrollPane to the GUI screen.
			JOptionPane.showMessageDialog(null, getScroller(), "List of Stop Words", JOptionPane.INFORMATION_MESSAGE);
		}
		
		//If the "Previous results" button is pressed.
		if(event.getSource()== getResultsButton())
		{
			setArea1(new JTextArea("Results:\n")); //Set area1 to a new text area.
			getArea1().setEditable(false); //Disables user from editing the file.
			getArea1().setLineWrap(false); //Size changes depending on length of the sentence in the text area.
			add(getArea1()); 
			setVisible(true);
			
			for (Results element: getResultList())
			{
				getArea1().append(element.toString());
			}
			
			//Print out the results as an information message.
			JOptionPane.showMessageDialog(null, getArea1(), "List of Results", JOptionPane.INFORMATION_MESSAGE);
		}
		
		//If "Delete Results" button is pressed.
		if (event.getSource()==getDeleteResults())
		{
			getArea1().setText(" "); //Empty area1 of its contents.
			getResultList().clear(); //Clear the array list holding results.
			JOptionPane.showMessageDialog(this, "Previous Results have been cleared."); //Inform user that the results have been deleted.
		}
	
		//If user presses the add stop word button.
		if (event.getSource()==getAddButton())
		{
			setError1(0);
			
			//If the text field contains white space, then more than 1 word was entered.
			if(getAddField().getText().contains(" "))
			{
				//Inform the user of their error.
				JOptionPane.showMessageDialog(this, "Error: Please enter a single word to add.");
			}
			else
			{
				//Set addition to the word in the text field.
				setAddition(getAddField().getText());
				
				setError1(getMyStop().AddWord(getAddition())); //Send the Addition in to a method that will add it to the stop words list.
				
				if(getError1()>0)
				{
					//If "Error" is more than zero then an error has been caught so inform the user.
					JOptionPane.showMessageDialog(this, "\"" + getAddition() + "\" is already in stopWords.");
				}
				else
				{
					//Inform the user that their selected word has been added.
					JOptionPane.showMessageDialog(this, "\"" + getAddition() + "\" has been added to the stop words list.");
				}
			}
		}
		
		//If the user presses the delete stop word button.
		if (event.getSource()==getDeleteButton())
		{
			setError2(0);
			
			if(getDeleteField().getText().contains(" "))
			{
				//Inform the user of their error.
				JOptionPane.showMessageDialog(this, "Error: Please enter a single word to delete.");
			}
			else
			{
				//Set addition to the word in the text field.
				setWordToDelete(getDeleteField().getText());
				
				setError2(getMyStop().DeleteWord(getWordToDelete())); //Send the Addition in to a method that will add it to the stop words list.
				
				
				if(getError2()>0)
				{
					JOptionPane.showMessageDialog(this, "\"" + getWordToDelete() + "\" was not found in stopWords.");
				}
				else
				{
					//Inform the user that their selected word has been deleted.
					JOptionPane.showMessageDialog(this, "\"" + getWordToDelete() + "\" has been removed from the stop words list.");
				}
			}
		}
	}

	//Method that saves  the top 15 words in an array list.
	public ArrayList<String> FindTop15(TreeMap<String, Integer> Map)
	{
		setFullList(new ArrayList<String>(Map.keySet())); //Creates an arraylist and puts all the values from the map in to the list.
		setTopFifteenWords(new ArrayList<String>()); //Create another list to only store the first 15.
			
		getTopFifteenWords().clear(); //Erase contents so two maps will not be saved in the one list.
		
        for(setI(0); getI()<15; i++) //Repeat 15 times.
        {
        	try
        	{
        		getTopFifteenWords().add(getFullList().get(getI())); //Add the "i" element of the FullList to the "TopFifteenWords" list.
        	}
        	catch(Exception ex)
			{
        		return getTopFifteenWords();
			}	
        }
        
		return getTopFifteenWords(); //Return the array list.
	}
	
	//Method that adds up the number of similar words from each top15.
	public int FindSimilarity(ArrayList<String> Top1, ArrayList<String> Top2) //Takes in the two lists and returns an int.
	{
		setPercentage(0);

		for(setI(0); getI()<Top1.size(); i++) //Loops until Top1 has no more elements.
		{
			try
			{
				if(Top1.contains(Top2.get(getI()))) //If a word in top1 is found in top2.
				{
					setPercentage(getPercentage() + 1); //Increment "percentage"
				}
			}
	    	catch(Exception ex)
			{
			}	
		}
		
		//If the two files have the same top word, I think this should merit extra points.
		if(Top1.get(0).equals(Top2.get(0)))
		{
			setPercentage(getPercentage()+2); //Add 2 to Percentage.
		}
		
		setPercentage(getPercentage() * 10); //Multiply "Percentage" by ten to give the number as a percentage out of 100.
		
		if(getPercentage()>100) //This can go over 100 because I am reading the top 15 words.
		{
			setPercentage(100); //If it is more than 100, set it to 100.
		}
		
		return getPercentage(); //Return the int percentage.
	}

	
	//Getters and Setters
	public JLabel getLabel1() 
	{
		return Label1;
	}


	public void setLabel1(JLabel label1) 
	{
		Label1 = label1;
	}


	public JTextField getField1() 
	{
		return Field1;
	}


	public void setField1(JTextField field1) 
	{
		Field1 = field1;
	}


	public JTextField getField2() 
	{
		return Field2;
	}


	public void setField2(JTextField field2) 
	{
		Field2 = field2;
	}


	public JTextField getAddField() 
	{
		return AddField;
	}


	public void setAddField(JTextField addField) 
	{
		AddField = addField;
	}


	public JTextField getDeleteField() 
	{
		return DeleteField;
	}


	public void setDeleteField(JTextField deleteField) 
	{
		DeleteField = deleteField;
	}


	public JPanel getPanel1() 
	{
		return Panel1;
	}


	public void setPanel1(JPanel panel1) 
	{
		Panel1 = panel1;
	}


	public JPanel getPanel2() 
	{
		return Panel2;
	}


	public void setPanel2(JPanel panel2) 
	{
		Panel2 = panel2;
	}


	public JPanel getStopPanel() 
	{
		return StopPanel;
	}


	public void setStopPanel(JPanel stopPanel) 
	{
		StopPanel = stopPanel;
	}


	public JPanel getPanel4() 
	{
		return Panel4;
	}


	public void setPanel4(JPanel panel4) 
	{
		Panel4 = panel4;
	}


	public JButton getCompareButton() 
	{
		return CompareButton;
	}


	public void setCompareButton(JButton compareButton) 
	{
		CompareButton = compareButton;
	}


	public JButton getShowButton() 
	{
		return ShowButton;
	}


	public void setShowButton(JButton showButton) 
	{
		ShowButton = showButton;
	}


	public JButton getAddButton() 
	{
		return AddButton;
	}


	public void setAddButton(JButton addButton) 
	{
		AddButton = addButton;
	}


	public JButton getDeleteButton() 
	{
		return DeleteButton;
	}


	public void setDeleteButton(JButton deleteButton) 
	{
		DeleteButton = deleteButton;
	}


	public JButton getResultsButton() 
	{
		return ResultsButton;
	}


	public void setResultsButton(JButton resultsButton) 
	{
		ResultsButton = resultsButton;
	}


	public JButton getChooseButton1() 
	{
		return ChooseButton1;
	}


	public void setChooseButton1(JButton chooseButton1) 
	{
		ChooseButton1 = chooseButton1;
	}


	public JButton getChooseButton2() 
	{
		return ChooseButton2;
	}


	public void setChooseButton2(JButton chooseButton2) 
	{
		ChooseButton2 = chooseButton2;
	}


	public String getFirstChoice() 
	{
		return FirstChoice;
	}


	public void setFirstChoice(String firstChoice) 
	{
		FirstChoice = firstChoice;
	}


	private String getSecondChoice() 
	{
		return SecondChoice;
	}


	private void setSecondChoice(String secondChoice) 
	{
		SecondChoice = secondChoice;
	}


	public String getsWords() 
	{
		return sWords;
	}


	public void setsWords(String sWords) 
	{
		this.sWords = sWords;
	}


	public JLabel getLabel2() 
	{
		return Label2;
	}


	public void setLabel2(JLabel label2) 
	{
		Label2 = label2;
	}


	public JLabel getStopLabel() 
	{
		return StopLabel;
	}


	public void setStopLabel(JLabel stopLabel) 
	{
		StopLabel = stopLabel;
	}


	public JLabel getFileLabel() 
	{
		return FileLabel;
	}


	public void setFileLabel(JLabel fileLabel) 
	{
		FileLabel = fileLabel;
	}


	public JButton getDeleteResults() {
		return DeleteResults;
	}


	public void setDeleteResults(JButton deleteResults) {
		DeleteResults = deleteResults;
	}


	public int getPercentage() {
		return Percentage;
	}


	public void setPercentage(int percentage) {
		Percentage = percentage;
	}


	public int getI() {
		return i;
	}


	public int setI(int i) {
		this.i = i;
		return i;
	}


	public int getPercent() {
		return Percent;
	}


	public void setPercent(int percent) {
		Percent = percent;
	}


	public int getError2() {
		return Error2;
	}


	public void setError2(int error2) {
		Error2 = error2;
	}


	public int getError1() {
		return Error1;
	}


	public void setError1(int error1) {
		Error1 = error1;
	}


	public JScrollPane getScroller() {
		return Scroller;
	}


	public void setScroller(JScrollPane scroller) {
		Scroller = scroller;
	}


	public TreeMap<String, Integer> getMap1() {
		return Map1;
	}


	public void setMap1(TreeMap<String, Integer> map1) {
		Map1 = map1;
	}


	public TreeMap<String, Integer> getMap2() {
		return Map2;
	}


	public void setMap2(TreeMap<String, Integer> map2) {
		Map2 = map2;
	}


	public JTextArea getListOfStops() {
		return listOfStops;
	}


	public void setListOfStops(JTextArea listOfStops) {
		this.listOfStops = listOfStops;
	}


	public JTextArea getArea1() {
		return area1;
	}


	public void setArea1(JTextArea area1) {
		this.area1 = area1;
	}


	public String getWordToDelete() {
		return wordToDelete;
	}


	public void setWordToDelete(String wordToDelete) {
		this.wordToDelete = wordToDelete;
	}


	public String getAddition() {
		return Addition;
	}


	public void setAddition(String addition) {
		Addition = addition;
	}


	public ArrayList<String> getTopFifteenWords() {
		return TopFifteenWords;
	}


	public void setTopFifteenWords(ArrayList<String> topFifteenWords) {
		TopFifteenWords = topFifteenWords;
	}


	public ArrayList<String> getTop15_1() {
		return Top15_1;
	}


	public void setTop15_1(ArrayList<String> top15_1) {
		Top15_1 = top15_1;
	}


	public ArrayList<String> getTop15_2() {
		return Top15_2;
	}


	public void setTop15_2(ArrayList<String> top15_2) {
		Top15_2 = top15_2;
	}


	public ArrayList<Results> getResultList() {
		return ResultList;
	}


	public void setResultList(ArrayList<Results> resultList) {
		ResultList = resultList;
	}


	public ArrayList<String> getFullList() {
		return FullList;
	}


	public void setFullList(ArrayList<String> fullList) {
		FullList = fullList;
	}


	public Stop_Words getMyStop() {
		return myStop;
	}


	public void setMyStop(Stop_Words myStop) {
		this.myStop = myStop;
	}


	public fileChooser getMyChooser() {
		return myChooser;
	}


	public void setMyChooser(fileChooser myChooser) {
		this.myChooser = myChooser;
	}


	public FileProcessor_Assignment getMyReader() {
		return myReader;
	}


	public void setMyReader(FileProcessor_Assignment myReader) {
		this.myReader = myReader;
	}
}