/********************************
 * Author: Jamie Walsh (C16358056)
 * Control Class
 * 28-03-2018
 ********************************/
package com.Assignment.C16358056;

public class Assignment_Control 
{
	public static void main(String[] args) 
	{
		Assignment_GUI myScreen= new Assignment_GUI("Jamie's Topic Analyser");
	}
}