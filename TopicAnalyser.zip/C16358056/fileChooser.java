package com.Assignment.C16358056;

import java.io.File;
import javax.swing.JFileChooser;

public class fileChooser 
{
	private final JFileChooser Chooser= new JFileChooser(); //instantiate the JFile Chooser
	private File file1; //Creating a local variable for the user's chosen file.
	private static String fileName; //This String needs to be static so it can be used in the "Assignment_GUI" class.
	private static String Error= null;
	
	//Method for using the JFileChooser.
	public void fChoose()
	{		
		getChooser().setCurrentDirectory(new File("C:/Users/Home/OneDrive/TextFiles")); //Sets the starting directory of the jFileChooser.
		getChooser().setFileSelectionMode(JFileChooser.FILES_ONLY); //Only allows the user to select files.
		getChooser().setDialogTitle("Choose a Text File"); //Sets the title of the JFileChooser.

		if(getChooser().showOpenDialog(null) == JFileChooser.APPROVE_OPTION) //If the user presses the OK button.
		{
			setError(null); //Ensure Error still equals null.
			
			try
			{
				setFile1(getChooser().getSelectedFile()); //Setting the file to the user's chosen one.
				setFileName(getFile1().getAbsolutePath()); //entering the directory in to the string, "fileName".		
			}
			catch(Exception ex)
			{
				System.out.println("Error: Exception " + ex.getMessage() + " caught.");
			}	
		}
		else
		{
			//Change the value of "Error" so the error message will be displayed from the GUI class.
			setError("Error");
		}	
	}

	//Getters and Setters
	public static String getFileName() {
		return fileName;
	}

	public static void setFileName(String fileName) {
		fileChooser.fileName = fileName;
	}

	public static String getError() {
		return Error;
	}

	public static void setError(String error) {
		Error = error;
	}

	public File getFile1() {
		return file1;
	}

	public void setFile1(File file1) {
		this.file1 = file1;
	}

	public JFileChooser getChooser() {
		return Chooser;
	}
}
