/********************************
 * Author: Jamie Walsh (C16358056)
 * Class used to remove stopwords from files.
 * 30-03-2018
 ********************************/

package com.Assignment.C16358056;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.TreeMap;

public class Stop_Words 
{
	//Attributes: 
	private int i;
	private int j;
	private int Error;
	private int Error2;
	private int Size;
	private String A2String;

	//An arraylist containing all the stop words. I got this set of words from a website online.
	//I made it static so changes made in different methods will be saved.
    private static ArrayList<String> stopWords = new ArrayList<>(Arrays.asList("a", "as", "able", "about",
			 "above", "according", "accordingly", "across", "actually", "after", "afterwards", "again", "against", "aint", "all", "allow", "allows", "almost", "alone", "along", "already",
			 "also", "although", "always", "am", "among", "amongst", "an", "and", "another", "any", "anybody", "anyhow", "anyone", "anything", "anyway", "anyways", "anywhere", "apart", "appear", 
			 "appreciate", "appropriate", "are", "arent", "around", "as", "aside", "ask", "asking", "associated", "at", "available", "away", "awfully", "be", "became", "because", "become", "becomes",
			 "becoming", "been", "before", "beforehand", "behind", "being", "believe", "below", "beside", "besides", "best", "better", "between", "beyond", "both", "brief", "but", "by", "cmon", "cs", 
			 "came", "can", "cant", "cannot", "cant", "cause", "causes", "certain", "certainly", "changes", "clearly", "co", "com", "come", "comes", "concerning", "consequently", "consider", "considering", "contain",
			 "containing", "contains","corresponding", "could", "couldnt", "course", "currently", "definitely", "described", "despite", "did", "didnt", "different", "do", "does", "doesnt", "doing", "dont", "done", 
			 "down", "downwards", "during", "each", "edu", "eg", "eight", "either", "else", "elsewhere", "enough", "entirely", "especially", "et", "etc", "even", "ever", "every", "everybody", "everyone", "everything", 
			 "everywhere", "ex", "exactly", "example", "except", "far", "few", "fifth", "first", "five", "followed", "following", "follows", "for", "former", "formerly", "forth", "four", "from", "further",
			 "furthermore", "get", "gets", "getting", "given", "gives", "go", "goes", "going", "gone", "got", "gotten", "greetings", "had", "hadnt", "happens", "hardly", "has", "hasnt", "have",
			 "havent", "having", "he", "hes", "hello", "help", "hence", "her", "here", "heres", "hereafter", "hereby", "herein", "hereupon", "hers", "herself", "hi", "him", "himself", "his", "hither", "hopefully", "how", 
			 "howbeit", "however", "i", "id", "ill", "im", "ive", "ie", "if", "ignored", "immediate", "in", "inasmuch", "inc", "indeed", "indicate", "indicated", "indicates", "inner", "insofar", "instead", "into", "inward", 
			 "is", "isnt", "it", "itd", "itll", "its", "its", "itself", "just", "keep", "keeps", "kept", "know", "knows", "known", "last", "lately", "later", "latter", "latterly", "least", "less", "lest", "let", "lets", "like", 
			 "liked", "likely", "little", "look", "looking", "looks", "ltd", "mainly", "many", "may", "maybe", "me", "mean", "meanwhile", "merely", "might", "more", "moreover", "most", "mostly", "much", "must", "my", 
			 "myself", "name", "namely", "nd", "near", "nearly", "necessary", "need", "needs", "neither", "never", "nevertheless", "new", "next", "nine", "no", "nobody", "non", "none", "noone", "nor", "normally", "not", "nothing", 
			 "novel", "now", "nowhere", "obviously", "of", "off", "often", "oh", "ok", "okay", "old", "on", "once", "one", "ones", "only", "onto", "or", "other", "others", "otherwise", "ought", "our", "ours", "ourselves", "out", 
			 "outside", "over", "overall", "own", "particular", "particularly", "per", "perhaps", "placed", "please", "plus", "possible", "presumably", "probably", "provides", "que", "quite", "qv", "rather", "rd", "re", "really", 
			 "reasonably", "regarding", "regardless", "regards", "relatively", "respectively", "right", "said", "same", "saw", "say", "saying", "says", "second", "secondly", "see", "seeing", "seem", "seemed", "seeming", "seems", 
			 "seen", "self", "selves", "sensible", "sent", "serious", "seriously", "seven", "several", "shall", "she", "should", "shouldnt", "since", "six", "so", "some", "somebody", "somehow", "someone", "something", "sometime", 
			 "sometimes", "somewhat", "somewhere", "soon", "sorry", "specified", "specify", "specifying", "still", "sub", "such", "sup", "sure", "ts", "take", "taken", "tell", "tends", "th", "than", "thank", "thanks", "thanx", "that", 
			 "thats", "thats", "the", "their", "theirs", "them", "themselves", "then", "thence", "there", "theres", "thereafter", "thereby", "therefore", "therein", "theres", "thereupon", "these", "they", "theyd", "theyll", "theyre", 
			 "theyve", "think", "third", "this", "thorough", "thoroughly", "those", "though", "three", "through", "throughout", "thru", "thus", "to", "together", "too", "took", "toward", "towards", "tried", "tries", "truly", "try", 
			 "trying", "twice", "two", "un", "under", "unfortunately", "unless", "unlikely", "until", "unto", "up", "upon", "us", "use", "used", "useful", "uses", "using", "usually", "value", "various", "very", "via", "viz", "vs", 
			 "want", "wants", "was", "wasnt", "way", "we", "wed", "well", "were", "weve", "welcome", "well", "went", "were", "werent", "what", "whats", "whatever", "when", "whence", "whenever", "where", "wheres", "whereafter", "whereas", 
			 "whereby", "wherein", "whereupon", "wherever", "whether", "which", "while", "whither", "who", "whos", "whoever", "whole", "whom", "whose", "why", "will", "willing", "wish", "with", "within", "without", "wont", "wonder", 
			 "would", "would", "wouldnt", "yes", "yet", "you", "youd", "youll", "youre", "youve", "your", "yours", "yourself", "yourselves", "zero"
    ));
    
	//Constructor.
	public Stop_Words()
	{
		
	}
	
	//Method that takes in the map and removes the stop words.
	public TreeMap<String, Integer> RemoveStopWords(TreeMap<String, Integer> RawWords)
	{
		RawWords.keySet().removeAll(stopWords); //This removes all the stopWords and their key values from the map.

		return RawWords;
	}
	
	//Method that returns the stopwords as a string.
	public String getStopW()
	{
		setA2String(stopWords.toString()); //save the stopwords in to the string "A2String".
		return getA2String();
	}
	
	//Method that adds in the user's selected word to stopwords.
	public int AddWord(String addThis)
	{
		setError(0); //Set error to zero.
		
		//If the words is already in stopwords.
		if(stopWords.contains(addThis))
		{
			setError(1); //Set error to 1.
		}
		else
		{
			stopWords.add(addThis); //Add the new words to the stopwords list.
		}
		
		return getError(); //Return the Error number so the correct message will be displayed in the GUI class.
	}
	
	//Method to delete the user's selected word from the stop words list.
	public int DeleteWord(String deleteThis)
	{	
		setError2(0);
		
		//If the words is already in stopwords.
		if(stopWords.contains(deleteThis))
		{
			stopWords.remove(deleteThis); //Remove the word from the list.
		}
		else
		{
			setError2(1); //Set "Error2" to 1.
		}
		
		return getError2(); //Return the Error2 number so the correct message will be displayed in the gui class.
	}

	
	//Getters and Setters
	public int getI() {
		return i;
	}

	public void setI(int i) {
		this.i = i;
	}

	public int getJ() {
		return j;
	}

	public void setJ(int j) {
		this.j = j;
	}

	public int getError() {
		return Error;
	}

	public void setError(int error) {
		Error = error;
	}

	public int getError2() {
		return Error2;
	}

	public void setError2(int error2) {
		Error2 = error2;
	}

	public int getSize() {
		return Size;
	}

	public void setSize(int size) {
		Size = size;
	}

	public String getA2String() {
		return A2String;
	}

	public void setA2String(String a2String) {
		A2String = a2String;
	}
}
